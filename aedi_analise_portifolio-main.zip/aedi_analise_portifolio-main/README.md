# aedi_analise_portifolio
Simulação Monte Carlo - Disciplina AEDI UNB
